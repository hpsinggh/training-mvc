package com.cns.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@RequestMapping(value="/login" , method=RequestMethod.GET)
	public ModelAndView getLoginPage()
	{
		return new ModelAndView("Login","u",new Login());
		
	}
	@RequestMapping(value="/submit",method=RequestMethod.POST)
	public ModelAndView submitLoginForm(@Valid @ModelAttribute ("u") Login user,BindingResult br)
	{
		System.out.println("submit controller");
		if(br.hasErrors())
		{
			return new ModelAndView("Login");
		}
		else
		{
			String uname=user.getUsername();
			String pword=user.getPassword();
			if(uname.equals("Arjun")&& pword.equals("daddy"))
			{
				return new ModelAndView("Success" ,"msg","you are a valid user...");
			}
			else
			{
				return new ModelAndView("Fail" ,"msg" ,"you are not a valid user...");
			}
		}
	}
}
