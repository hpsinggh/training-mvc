package com.cns.controller;


import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

//import org.hibernate.validator.constraints.NotEmpty;   //hibarnate-validator dependency

public class Login {
	@Size(min=4,max=10)
	@Pattern(regexp="^[A-Z][a-z]*")   //that's why we added javax.validation dependency in pom.xml
	private String username;
//	@NotEmpty
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
