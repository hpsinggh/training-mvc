package com.smd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AnnotatedController{

	@RequestMapping("/address")
	public ModelAndView AddressController() {
		//ModelAndView mov=new ModelAndView("welcome");
		ModelAndView mov=new ModelAndView("address","messagekey","DPS,Indrapuram,Ghaziabad");
		return mov;
	}
}
										