package com.smd.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/*
 This project implementing following request handler classes.-
 1.Bean name url handler mapping 
 2.simple url handler mapping 
 3.UrlFilenameViewController 
 4.Default annotation handler mapping 
 5.ParameterizableViewController
 6.traditional and annotated controllers
 additionally it also implements InternalResourceViewResolver class.
 */


public class TraditionalController extends AbstractController{

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ModelAndView mov=new ModelAndView("home");
		return mov;
	}

}
